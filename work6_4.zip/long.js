let users = [
    { name: 'Вася', age: 18 },
    { name: 'Петя', age: 20 },
    { name: 'Саша', age: 17 },
]

for (let i = 0; i < users.length; i++) {
    console.log(`Это ${users[i].name}, ему ${users[i].age} лет`)
}

let usersStr = 'Вася, Петя, Надя, Даша, Аня'
let users1 = usersStr.split(',')
console.log(users1);

