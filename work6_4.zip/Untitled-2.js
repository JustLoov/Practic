i = 1

while (i <= 10) {
    alert(`Число ${i}!`)
    i++
}

let usersName = ['Alex', 'John', '', 'David', 'Samuel']

// for (let i = 0; i <= usersName.length; i++) {
//     if (!usersName[i]) break
//     console.log(usersName[i])
// }             Цикл останавливается как только достигает пробела

for (let i = 0; i < usersName.length; i++) {
    if (!usersName[i]) continue
    console.log(usersName[i])
}

// цикл пропускает пробел