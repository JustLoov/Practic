let username = "Ilya";

alert(`hello ${username}`)

let num = 2
let str = 'Привет 1Т'
let bool = false
let obj = null
let UserSymbol = Symbol('user')
let adress;
let more = {
    
}



console.log(`
Переменная со значением num является типом ${typeof num}
Переменная со значением str является типом ${typeof str}
Переменная со значением bool является типом ${typeof bool}
Переменная со значением obj является типом ${typeof obj}
Переменная со значением UserSymbol является типом ${typeof UserSymbol}
Переменная со значением adress является типом ${typeof adress}
Переменная more является типом ${ typeof more }`)

let text = prompt('Введите текст')
alert(`длина текста ${text.length}`)