
let num1 = +prompt('Введите 1 число: ')
let num2 = +prompt('Введите 2 число: ')
console.log(`
${num1} * ${num2} = ${num1 * num2}
${num1} + ${num2} = ${num1 + num2}
${num1} - ${num2} = ${num1 - num2}
${num1} / ${num2} = ${num1 / num2}
${num1} % ${num2} = ${num1 % num2}
${num1} ** ${num2} = ${num1 ** num2}
`)

