let len = +prompt('Введите длину комнаты')
let width = +prompt('Введите ширину комнаты')

let s = (`площадь комнат: ${len} * ${width} = ${len * width} `)
console.log(s);