function calculate_sum(n) {
    if (n > 1) {
        return n + calculate_sum(n - 1);
    }
    return n;
}

console.log(calculate_sum(17)) // не поверите, но это тоже пример

