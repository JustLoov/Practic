
function isAdult(age) {
    return (age > 14)
}
console.log(isAdult(13));
console.log(isAdult(15)); // для примера что функция работает

function season(month) {
    if ([1, 2, 12].includes(month)) return 'Зима'
    else if ([3, 4, 5].includes(month)) return 'Весна'
    else if ([6, 7, 8].includes(month)) return 'Лето'
    else if ([9, 10, 11].includes(month)) return 'Осень'
    else return 'Нет такого сезона'
}

console.log(season(8)); // так же для примера
