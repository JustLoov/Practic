function count(string, letter) {
    let total = 0
    for (let i = 0; i < string.length; i++) {
        if (string[i] === letter)
            ++total
    }
    return total
}
console.log(count('привет', 'и')); // вааау это же пример

function sortNumbers(max) {
    let obj = {
        evenNums: [],
        oddNums: []
    }
    for (let i = 1; i <= max; i++) {
        obj[i % 2 ? 'oddNums' : 'evenNums'].push(i)
    }
    return obj
}

console.log(sortNumbers(10)); // это тоже пример, я тоже удивлён
