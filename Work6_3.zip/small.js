let a1 = +prompt("Первое число?", 1);
let b1 = +prompt("Второе число?", 2);

alert(a1 + b1); // 3



let year = prompt('Введите год')

if (year % 4 == 0) {
    console.log("Високосный")
} else if (year % 4 == 1) {
    console.log("Не високосный")
}
