let num1 = +prompt("Введите длину стороны")

let S = (`${num1 ** 2}`)
let P = (`${num1 + num1 + num1 + num1}`)

console.log(S);
console.log(P);
alert(`Площадь и периметр квадрата равны = ${S} и ${P} `)