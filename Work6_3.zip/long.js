let x = 1
let y = 1



let a = ++x; // 2
let b = y++; // 1

console.log(a);
console.log(b);

let x1 = 4;
let y1 = 3 + (x1 *= 3); // x = 3 + (4*3)

console.log(y1);