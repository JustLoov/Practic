class worker {
    constructor(name, surname, rate, days) {
        this.name = name
        this.surname = surname
        this.rate = rate
        this.days = days
    }
    getname(){
        return this.name
    }
    getsurname(){
        return this.surname
    }
    getsalary() {
        return this.rate * this.days
    }
    getfullname(){
        return `${this.name} ${this.surname}`
    }
    getrate() {
        return this.rate
    }
    getdays() {
        return this.days
    }
    setrate(rate) {
        this.rate = rate
    }
    setdays(days){
        this.days = days
    }

}

let Artem = new worker("Артём", "Гаврилов", 2000, 28)
let Maxim = new worker("Максим", "Абубакиров", 2000, 20)

console.log(Artem.getname());
console.log(Artem.getsurname());
console.log(Artem.getrate());
console.log(Artem.getdays());
console.log(Artem.getsalary());

console.log(Maxim.getname());
console.log(Maxim.getsurname());
console.log(Maxim.getrate());
console.log(Maxim.getdays());
console.log(Maxim.getsalary());

Artem.setrate(13);
Artem.setdays(15);
console.log("Зарплата Артёма со штрафами", Artem.getsalary());


