class User {
    constructor(name, surname) {
        this.name = name
        this.surname = surname
    }
    getfullname() {
        return `${this.name} ${this.surname}`
    }
}

class Student extends User {
    constructor(name, surname, year) {
        super(name, surname);
        this.year = year
    }
    getcourse() {
        let year = new Date().getFullYear();
        if (this.year > 2017 && this.year < 2022) {
            return year - this.year;
        }
    }
}

let Artemka = new Student("Артём", "Гаврилов", 2020)

console.log(Artemka.name);
console.log(Artemka.surname);
console.log(Artemka.getfullname());
console.log(Artemka.year);
console.log(Artemka.getcourse());